﻿# 🍽️ Restoran Nusantara — Sistem Informasi Restoran Terintegrasi

Prototype aplikasi web restoran yang mengimplementasikan **5 modul** dari dokumen blueprint:
pemesanan scan barcode, kasir POS, reservasi meja, manajemen stok, dan laporan keuangan standar akuntansi.

Dirancang agar **dapat langsung dijalankan & didemokan di laptop** tanpa Docker, database server, atau
payment gateway sungguhan.

---

## 🚀 Cara Menjalankan

```bash
npm install          # pasang dependency
npm run db:seed      # buat & isi database (SQLite) dengan data demo
npm run dev          # jalankan server → http://localhost:3000
```

> Database otomatis di-seed saat aplikasi pertama kali diakses, jadi `db:seed` opsional.

### Akun Demo

| Username | Password | Role | Kemampuan |
|---|---|---|---|
| `admin` | `admin123` | Administrator | Akses penuh + panel admin |
| `manager` | `manager123` | Manager | Stok, PO, void, seluruh laporan keuangan |
| `kasir` | `kasir123` | Kasir | POS, shift kasir, Z-Report, check-in tamu |
| `customer` | `customer123` | Customer | Scan barcode, pesan, buat reservasi |

Halaman **Customer Portal**, **Kitchen Display**, dan **Beranda** dapat diakses tanpa login.

---

## 📚 Peta Modul

| Modul | Halaman | Rute | Fitur Utama |
|---|---|---|---|
| **1. Customer Portal** | `/customer` | Scan barcode (kamera ZXing + input manual), katalog menu, keranjang, catatan item, 4 metode bayar, struk digital, riwayat & tracking pesanan |
| **2. POS / Kasir** | `/pos` | Opening/closing shift, katalog touch, void transaksi, Z-Report, cetak struk 80mm, kontrol ketersediaan menu |
| **2. Kitchen Display** | `/kitchen` | 3 kolom status (masuk → masak → siap), timer pesanan, berubah otomatis antar tab |
| **3. Reservasi** | `/booking` | Cek ketersediaan slot, denah ruangan, 4 paket, deposit 25%, QR e-ticket, check-in, pembatalan + refund |
| **4. Stok & Bahan Baku** | `/inventory` | Alert stok menipis & kedaluwarsa, Purchase Order, penerimaan GRN (moving average), stock opname, resep & HPP |
| **5. Laporan Keuangan** | `/reports` | Dashboard chart, Laba Rugi, Neraca Saldo, Arus Kas, penjualan per produk/kasir/metode, Buku Besar, Laporan PPN, ekspor CSV |
| **Payment Gateway** | `/pay/[token]` | Halaman QRIS / Kartu / VA (simulasi Midtrans–Xendit), signature HMAC-SHA512, webhook idempotent, struk PDF 80mm |
| **Notifikasi** | `/notifications` | Outbox email/SMS/WhatsApp, monitor transaksi gateway, log webhook, event realtime |
| **Admin** | `/admin` | Manajemen akun, matriks RBAC, status keamanan, riwayat ekspor laporan, aktivitas jurnal |
| **PWA & Offline** | `/offline` | Install ke home screen, keranjang tersimpan di IndexedDB, antrean pesanan offline, push notification |

---

## 🏗️ Arsitektur

```
┌──────────────────────────────────────────────────────────────┐
│  PRESENTATION  — Next.js 14 App Router + Tailwind CSS (PWA)   │
│   /customer  /pos  /kitchen  /booking  /inventory  /reports │
├──────────────────────────────────────────────────────────────┤
│  APPLICATION  — Route Handlers + Zod validation + RBAC guard │
│                  src/app/api/v1/**                           │
├──────────────────────────────────────────────────────────────┤
│  DOMAIN       — order · booking · inventory · report service │
│                  (tidak tahu-menahu HTTP maupun SQL)          │
├──────────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE — better-sqlite3 · repository · auth (JWT)   │
└──────────────────────────────────────────────────────────────┘
```

### Struktur Direktori

```
src/
├── app/                      # Halaman (App Router) + REST API Route Handlers
│   ├── api/v1/               # API sesuai blueprint §5
│   ├── customer|pos|kitchen|booking|inventory|reports|admin/
│   └── login/
├── components/               # AppShell, UI kit, Receipt, FloorMap, BarcodeScanner
├── lib/                      # store (state), api client, analytics, utils
├── server/                   # Backend (tidak pernah masuk bundle browser)
│   ├── auth/                 # scrypt password hashing + JWT (jose)
│   ├── db/                   # schema.sql, client, seed
│   ├── http/                 # ApiError, handler, requireUser
│   └── services/             # logika domain per modul
├── types/                    # TypeScript types
└── middleware.ts             # proteksi route berbasis role
```

---

## 🔗 Integrasi Antar Modul

| Dari | Ke | Yang Terjadi Otomatis |
|---|---|---|
| POS / Customer Order | **Stok** | Setiap penjualan memotong bahan baku sesuai resep (BOM) |
| POS / Customer Order | **Akuntansi** | 6 baris jurnal double-entry: Kas, Pendapatan, Service Charge, PPN, HPP, Persediaan |
| Reservasi | **Akuntansi** | Deposit → Kas (Dr) & Liabilitas Deposit (Cr) |
| Pembatalan reservasi | **Akuntansi** | Liabilitas dilepas, penalti diakui sebagai pendapatan |
| Stock Opname | **Akuntansi** | Dr Beban / Cr Persediaan (susut) atau Dr Persediaan / Cr Kas (koreksi) |
| Pembatalan transaksi | **Akuntansi** | Dr Beban Operasional / Cr Kas |
| Reservasi | **Meja** | Meja → `reserved`, lalu `occupied` saat check-in |
| Order lunas | **Stok** | Stok bahan dipotong **hanya saat order lunas**, bersamaan dengan pencatatan HPP |
| Payment Gateway | **Order / Booking** | Webhook terverifikasi -> lunas otomatis + jurnal + notifikasi |
| Setiap service | **Realtime** | Event dikirim ke KDS/customer via SSE tanpa polling |
| Semua laporan | **Jurnal** | Seluruh laporan dihitung ulang dari `ledger_entries` (satu sumber kebenaran) |

### Contoh Jurnal per Transaksi (Ayam Bakar ×2 + Es Teh ×2, Rp 97.020)

| Akun | Debit | Kredit |
|---|---:|---:|
| 1-100 Kas & Bank | 97.020 | — |
| 4-100 Pendapatan Penjualan | — | 84.000 |
| 4-100 Service Charge | — | 4.200 |
| 2-100 Utang PPN | — | 8.820 |
| 5-100 HPP | 27.300 | — |
| 1-200 Persediaan | — | 27.300 |

---

## 🔐 Keamanan

- **Password**: di-hash dengan `scrypt` (salt acak 16 byte, perbandingan *timing-safe*)
- **Sesi**: JWT HS256 di dalam cookie `HttpOnly` + `SameSite=Lax`, berlaku 2 jam
- **RBAC**: 4 role (`customer` < `cashier` < `manager` < `admin`) dijaga di dua lapis —
  `middleware.ts` untuk halaman, dan `requireUser()` untuk setiap endpoint sensitif
- **Validasi input**: seluruh request divalidasi dengan **Zod** sebelum menyentuh database
- **Rate limiting**: login dibatasi 5× gagal / 5 menit / IP (counter direset setelah login berhasil),
  POS 30 req/menit, webhook 120 req/menit. Lapisan kedua ada di Nginx (`limit_req_zone`)
- **Security headers**: CSP, HSTS, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy
- **SQL Injection**: seluruh query memakai *prepared statement* berparameter
- **Webhook payment**: signature HMAC-SHA512 diverifikasi (timing-safe), callback bersifat idempotent,
  dan request bersignature salah dicatat sebagai audit tetapi tidak dapat memblokir pembayaran sah
- **Audit trail**: login, penyesuaian stok, pembuatan pembayaran, dan ekspor laporan tercatat di tabel `audit_logs`

---

## 🗄️ Skema Database

**20 tabel**, `src/server/db/schema.sql`:

| Kelompok | Tabel |
|---|---|
| Auth & RBAC | `users` |
| Master data | `categories`, `menu_items`, `menu_recipes`, `restaurant_tables`, `suppliers`, `raw_materials`, `stock_items` |
| Transaksi | `customers`, `orders`, `order_items`, `payments` |
| Kasir | `pos_sessions` |
| Reservasi | `bookings`, `booking_payments`, `payment_configs` |
| Inventory | `purchase_orders`, `purchase_order_items`, `grn`, `stock_adjustments`, `stock_movements` |
| Akuntansi | `accounts`, `ledger_entries`, `financial_reports`, `tax_reports` |
| Audit | `audit_logs` |
| Payment Gateway (Phase 2) | `payment_webhooks` |
| Notifikasi (Phase 2) | `notifications`, `notification_templates` |

### Derbyang / Alur Data

```
Meja QR (NT-MEJA01)  ──scan──▶  Customer Portal  ──▶  orders + order_items
                                                       │
                          ┌────────────────────────────┼────────────────────┐
                          ▼                            ▼                    ▼
                   menu_recipes (BOM)          ledger_entries         stock_items
                   → potong stok               (double entry)        + stock_movements
```

---

## 🔌 Daftar API (mengikuti blueprint §5)

### Auth
| Method | Endpoint | Auth |
|---|---|---|
| POST | `/api/v1/auth/login` | publik |
| POST | `/api/v1/auth/register` | publik |
| GET/DELETE | `/api/v1/auth/me` | publik |

### Customer
| Method | Endpoint | Auth |
|---|---|---|
| POST | `/api/v1/customer/scan-barcode` | publik |
| GET | `/api/v1/customer/menu` | publik |
| GET | `/api/v1/menu/categories` | publik |
| GET | `/api/v1/menu/items` | publik |
| POST | `/api/v1/customer/orders` | publik |

### POS
| Method | Endpoint | Auth |
|---|---|---|
| GET/POST | `/api/v1/pos/session` | kasir |
| POST | `/api/v1/pos/transactions` | kasir |
| POST | `/api/v1/pos/transactions/:id/pay` | kasir |
| POST | `/api/v1/pos/transactions/:id/void` | manager |
| GET | `/api/v1/pos/receipt/:id` | kasir |

### Order & Dapur
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/v1/orders/:id` | publik |
| PATCH | `/api/v1/orders/:id` | publik (status KDS) |

### Booking
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/v1/booking/availability` | publik |
| GET/POST | `/api/v1/booking` | publik |
| GET/PATCH | `/api/v1/booking/:code` | publik / kasir |
| POST/PATCH | `/api/v1/booking/:code/payment` | publik / kasir |

### Inventory
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/v1/inventory` | publik |
| POST | `/api/v1/inventory/purchase-orders` | manager |
| POST | `/api/v1/inventory/purchase-orders/:id/receive` | manager |
| POST | `/api/v1/inventory/stock-adjustments` | manager |
| PATCH | `/api/v1/inventory/products/:id` | manager |

### Reports
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/v1/reports?type=pnl\|balance-sheet\|cash-flow\|sales\|tax\|ledger\|valuation\|trial-balance` | manager |
| GET/POST | `/api/v1/reports/export` | manager |

---

## 🐳 DevOps & Deployment

### Menjalankan dengan Docker

```bash
docker compose up --build          # aplikasi + PostgreSQL + Redis + MinIO
docker compose logs -f app         # log aplikasi
docker compose down -v             # berhenti & hapus volume
```

### Image produksi

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

Perbedaan produksi: aplikasi tidak publish port langsung (di mediating Nginx untuk TLS),
dibatasi CPU/memory, dan seluruh secret wajib diisi dari environment.

| Berkas | Isi |
|---|---|
| `Dockerfile` | Build 3 tahap: `deps` → `builder` → `runner` (non-root, healthcheck, standalone output) |
| `docker-compose.yml` | Stack pengembangan: app + PostgreSQL 16 + Redis 7 + MinIO |
| `docker-compose.prod.yml` | Override produksi: Nginx TLS + limit resource + secret wajib |
| `docker/nginx.conf` | TLS termination, gzip, cache statis, rate limit (auth 5r/m, API 30r/s), passthrough SSE |
| `.dockerignore` | Mengecilkan build context (node_modules, .next, data, tests) |
| `.github/workflows/ci.yml` | typecheck → test → build → smoke test → Docker build → Trivy scan |
| `.github/workflows/cd.yml` | Deploy ke VPS via SSH + health check + verifikasi |

### Health check

```bash
curl http://localhost:3000/api/health
```

Endpoint ini mengembalikan status database, **mengecek keseimbangan jurnal akuntansi**,
jumlah subscriber realtime, penggunaan memori, dan uptime. Docker, Nginx, dan platform
monitoring semuanya membaca endpoint yang sama.

### PWA & Mode Offline

| Fitur | Implementasi |
|---|---|
| Install ke home screen | Event `beforeinstallprompt` + manifest + service worker |
| Keranjang offline | IndexedDB via Dexie (`src/lib/offlineCart.ts`) |
| Antrean pesanan offline | Tabel `pendingOrders`, dikirim otomatis saat koneksi kembali |
| Push notification | Web Push API + handler `push` di service worker |
| Halaman offline | `/offline` sebagai fallback navigasi |

---

## ✅ Testing

```bash
npm test              # 17 unit + integration test (Vitest)
npx tsx scripts/smoke-api.ts   # 46 smoke test API end-to-end (butuh dev server)
npm run typecheck     # TypeScript strict, tanpa error
npm run build         # production build
```

**Cakupan test** (`tests/domain.test.ts`):

- Jurnal pembuka seimbang & seed master data lengkap
- Kalkulasi subtotal + service charge 5% + PPN 10%
- Penolakan pembayaran tunai kurang, menu nonaktif, booking bentrok, kapasitas kurang
- Potong stok sesuai resep BOM
- Jurnal double-entry seimbang setiap transaksi
- Konsistensi P&L ↔ Neraca ↔ Arus Kas
- Deposit 25% sebagai liabilitas; pembatalan + penalti → pendapatan
- Moving average saat GRN; penolakan GRN ganda & pengurangan melebihi stok
- Trial balance dan valuasi persediaan konsisten
- Signature webhook: menolak manipulasi nominal, menolak signature palsu
- Webhook duplikat idempotent (tidak double-credit)
- Webhook palsu tidak memblokir pembayaran sah (anti-DoS idempotency key)
- Stok fisik selalu sama dengan nilai buku di jurnal pada flow belum lunas -> lunas
- QRIS payload EMVCo + CRC16-CCITT
- Outbox notifikasi: render template, penerima kosong = failed, statistik kanal
- Receipt PDF valid (header %PDF-) dan 404 untuk struk tak ditemukan

---

## 📜 Perintah

| Perintah | Fungsi |
|---|---|
| `npm run dev` | Jalankan server pengembangan |
| `npm run build` / `npm start` | Build & jalankan versi produksi |
| `npm test` | Jalankan test suite (34 test) |
| `npm run smoke` | Smoke test API end-to-end (46 check) |
| `npm run smoke:phase2` | Smoke test payment/notifikasi/PDF/SSE (42 check) |
| `npm run typecheck` | Cek tipe TypeScript |
| `npm run db:seed` | Isi data awal |
| `npm run db:status` | Ringkasan isi database |
| `npm run db:reset` | Kosongkan & buat ulang database |
| `npm run backup` | Buat arsip ZIP seluruh source + snapshot database |
| `npm run backup:verify` | Verifikasi integritas arsip (CRC32 + kelengkapan) |
| `npm run icons` | Generate ikon PWA (192 & 512 px) |

> Catatan: `db:reset` mungkin gagal menghapus file bila dev server sedang berjalan (Windows file lock).
> Skrip otomatis beralih ke mode *truncate + seed ulang*. Hentikan server untuk reset bersih.

---

## 🎓 Catatan Teknis untuk Presentasi

**Kenapa SQLite, bukan PostgreSQL?**
Arsitektur target pada blueprint adalah PostgreSQL + Redis + MinIO dalam monorepo. Untuk keperluan
demo tugas, SQLite (file lokal) dipilih agar **tidak perlu Docker** — namun seluruh SQL yang dipakai
portabel, dan migrasi cukup mengganti driver + DDL.

**PPN 10% atau 11%?**
Implementasi memakai **PPN 10%** (`TAX_RATE = 0.1` di `src/lib/utils.ts`) karena jasa boga / restoran
dikenai PPN 10% — bukan 11% (yang berlaku untuk barang luxury). Semua label di UI, struk, dan
laporan sudah konsisten 10%.
**Pajak vs Service Charge**
Service charge 5% diperlakukan sebagai **pendapatan** (akun 4-100), sedangkan PPN dicatat sebagai
**kewajiban** (akun 2-100) — keduanya bukan beban, sehingga tidak mengurangi laba bersih.

**Neraca dijamin seimbang**
Nilai persediaan pada jurnal selalu berasal dari nilai fisiknya (`sum(quantity * unit_cost)`), dan setiap
transaksi selalu menghasilkan pasangan debit-kredit. Ini diverifikasi otomatis oleh assertion `balanced`
pada laporan serta oleh test suite.

**Peta jalan ke production** (sesuai blueprint): PostgreSQL + Prisma/TypeORM, NestJS sebagai backend
terpisah, Socket.io untuk KDS realtime, Midtrans/Xendit untuk payment gateway, Redis untuk cache & antrean,
Docker Compose + CI/CD.

---

*Prototype coursework Semester 3 — Pemrograman Web*
