/**
 * Next.js instrumentation hook — berjalan sekali saat server start.
 *
 * Tugasnya menyiapkan basis data sebelum request pertama dilayani:
 *  1. menjalankan DDL (CREATE TABLE IF NOT EXISTS) + migration,
 *  2. melakukan seeding bila database masih kosong.
 *
 * Dengan begitu container baru yang di-deploy tidak memerlukan langkah manual
 * (`npm run db:seed`) sebelum menerima traffic.
 */
export async function register() {
  // Hanya jalankan di server Node.js (bukan Edge runtime / middleware).
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;

  const { runMigrationsOnBoot } = await import('./server/db/client');

  try {
    const result = await runMigrationsOnBoot();
    console.log(
      `[boot] database siap (${result.database}) — tabel ${result.tables}, seed ${result.seeded ? 'dilakukan' : 'dilewati'}`
    );
  } catch (error) {
    // Server tetap start, namun log diperjelas agar mudah didiagnosis.
    console.error('[boot] GAGAL menyiapkan database:', error);
  }
}