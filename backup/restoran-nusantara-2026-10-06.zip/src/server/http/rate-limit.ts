/**
 * Rate limiter in-process (sliding window).
 *
 * Pada blueprint produksi, penyimpanannya adalah Redis. Implementasi ini memakai
 * Map global agar tidak menambah dependency, namun antarmukanya (jumlah
 * permintaan per jendela waktu per kunci) sama dengan yang akan dipakai Redis —
 * jadi penggantian ke Redis cukup mengubah satu file ini.
 */

interface Bucket {
  hits: number[];
}

const globalKey = '__restoRateLimiter';

declare global {
  // eslint-disable-next-line no-var
  var __restoRateLimiter: Map<string, Bucket> | undefined;
}

function store(): Map<string, Bucket> {
  if (!global[globalKey]) global[globalKey] = new Map();
  return global[globalKey];
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  limit: number;
  retryAfterSeconds: number;
}

export function rateLimit(
  key: string,
  options: { limit: number; windowMs: number }
): RateLimitResult {
  const now = Date.now();
  const windowStart = now - options.windowMs;
  const bucket = store().get(key) ?? { hits: [] };

  bucket.hits = bucket.hits.filter((t) => t > windowStart);

  if (bucket.hits.length >= options.limit) {
    const oldest = bucket.hits[0];
    store().set(key, bucket);
    return {
      allowed: false,
      remaining: 0,
      limit: options.limit,
      retryAfterSeconds: Math.max(1, Math.ceil((oldest + options.windowMs - now) / 1000)),
    };
  }

  bucket.hits.push(now);
  store().set(key, bucket);

  // Pembersihan berkala agar Map tidak tumbuh tanpa batas
  if (store().size > 5000) {
    for (const [k, v] of store()) {
      if (!v.hits.some((t) => t > windowStart)) store().delete(k);
    }
  }

  return {
    allowed: true,
    remaining: options.limit - bucket.hits.length,
    limit: options.limit,
    retryAfterSeconds: 0,
  };
}

/** Mengambil identitas klien dari header proxy (Vercel/Cloudflare/Nginx). */
export function clientKey(req: Request, scope = ''): string {
  const forwarded = req.headers.get('x-forwarded-for');
  const ip = forwarded?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || 'unknown';
  return `${scope}:${ip}`;
}

/** Membersihkan bucket (dipanggil setelah autentikasi berhasil). */
export function resetRateLimit(key: string) {
  store().delete(key);
}

/** Konfigurasi default per jenis endpoint. */
export const RATE_LIMITS = {
  // Hanya percobaan GAGAL yang dihitung (lihat resetRateLimit) sehingga user
  // sah tidak terkunci setelah login berulang kali.
  login: { limit: 5, windowMs: 5 * 60 * 1000 },
  register: { limit: 3, windowMs: 60 * 60 * 1000 },
  webhook: { limit: 120, windowMs: 60 * 1000 },
  order: { limit: 30, windowMs: 60 * 1000 },
  report: { limit: 60, windowMs: 60 * 1000 },
} as const;