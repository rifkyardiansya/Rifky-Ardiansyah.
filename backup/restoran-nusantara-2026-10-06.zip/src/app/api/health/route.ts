import crypto from 'node:crypto';
import { dbFilePath, ensureSeeded, getDb } from '@/server/db/client';
import { handler, ok } from '@/server/http/api';
import { listenerCount } from '@/server/realtime/bus';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const BOOTED_AT = Date.now();

/**
 * GET /api/health — health-check untuk Docker, load balancer, dan uptime monitor.
 *
 * Liveness  -> proses merespons (status selalu 200 selama route hidup)
 * Readiness -> database dapat diakses, ter-seed, dan jurnal seimbang
 */
export const GET = handler(async () => {
  const checks: Record<string, { ok: boolean; detail?: string; ms?: number }> = {};

  // Pastikan database siap (lazy seed) sebelum diperiksa
  await ensureSeeded();

  // 1. Database
  const dbStart = Date.now();
  try {
    const row = getDb()
      .prepare(
        `SELECT
           (SELECT COUNT(*) FROM menu_items)          AS menuItems,
           (SELECT COUNT(*) FROM restaurant_tables)  AS tables,
           (SELECT COUNT(*) FROM accounts)            AS accounts,
           (SELECT COUNT(*) FROM ledger_entries)      AS ledgerEntries,
           (SELECT COALESCE(SUM(debit),0) FROM ledger_entries)  AS totalDebit,
           (SELECT COALESCE(SUM(credit),0) FROM ledger_entries) AS totalCredit`
      )
      .get() as Record<string, number>;

    checks.database = {
      ok: true,
      ms: Date.now() - dbStart,
      detail: `${row.menuItems} menu, ${row.tables} meja, ${row.ledgerEntries} baris jurnal`,
    };

    // Jurnal harus seimbang — bila tidak, sistem dalam kondisi tidak sehat
    const balanced = Math.abs(row.totalDebit - row.totalCredit) < 1;
    checks.ledgerBalance = {
      ok: balanced,
      detail: balanced
        ? `seimbang (${row.totalDebit.toLocaleString('id-ID')})`
        : `TIDAK SEIMBANG: Dr ${row.totalDebit} vs Cr ${row.totalCredit}`,
    };
  } catch (error) {
    checks.database = { ok: false, detail: error instanceof Error ? error.message : 'tidak diketahui' };
  }

  // 2. Realtime (SSE bus)
  checks.realtime = { ok: true, detail: `${listenerCount()} subscriber aktif` };

  const healthy = Object.values(checks).every((c) => c.ok);

  return ok(
    {
      status: healthy ? 'healthy' : 'degraded',
      version: process.env.APP_VERSION ?? '1.0.0',
      commit: process.env.GIT_COMMIT ?? null,
      environment: process.env.NODE_ENV ?? 'development',
      runtime: process.env.NEXT_RUNTIME ?? 'nodejs',
      uptimeSeconds: Math.round((Date.now() - BOOTED_AT) / 1000),
      processUptime: Math.round(process.uptime()),
      memory: {
        rssMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
        heapUsedMb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      },
      databaseFile: dbFilePath,
      requestId: crypto.randomUUID().slice(0, 8),
      checks,
    },
    { status: healthy ? 200 : 503 }
  );
});