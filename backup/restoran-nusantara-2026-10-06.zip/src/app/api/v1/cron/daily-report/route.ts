import crypto from 'node:crypto';
import { z } from 'zod';
import { handler, ok } from '@/server/http/api';
import { hasRole, getSessionUser } from '@/server/auth/token';
import {
  buildDailyReport,
  generateAndDispatchDailyReport,
  listGeneratedReports,
} from '@/server/services/schedule.service';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * Endpoint cron harian.
 *
 * Contoh pemanggilan dari scheduler:
 *   0 23 * * *  curl -X POST https://app/api/v1/cron/daily-report \
 *                    -H "Authorization: Bearer $CRON_SECRET"
 *
 * Di-trigger juga oleh GitHub Actions schedule / Vercel Cron. Endpoint ini
 * dilindungi shared secret karena pemanggilnya mesin, bukan browser. Sesi
 * manager/admin juga diizinkan agar laporan dapat dijalankan manual dari UI.
 * Bersifat idempotent per tanggal sehingga cron yang berjalan dua kali tidak
 * mengirim notifikasi ganda.
 */
const CRON_SECRET = process.env.CRON_SECRET ?? 'dev-cron-secret';

async function authorized(req: Request) {
  const header = req.headers.get('authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : req.headers.get('x-cron-secret');

  if (token) {
    const a = Buffer.from(token);
    const b = Buffer.from(CRON_SECRET);
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) return true;
  }

  // Izinkan manager/admin yang sedang login (menjalankan manual dari UI)
  const user = await getSessionUser();
  return hasRole(user, 'manager');
}

export const POST = handler(async (req: Request) => {
  if (!(await authorized(req))) {
    return ok(
      { error: 'Unauthorized — butuh header Authorization: Bearer <CRON_SECRET> atau sesi manager.' },
      { status: 401 }
    );
  }

  const body = await req.json().catch(() => ({}));
  const { date } = z
    .object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() })
    .parse(body ?? {});

  const result = generateAndDispatchDailyReport(date);
  return ok(result);
});

/** GET — pratinjau laporan tanpa menyimpan, atau daftar riwayat bila punya akses. */
export const GET = handler(async (req: Request) => {
  const url = new URL(req.url);

  if (url.searchParams.get('preview') === '1') {
    return ok(buildDailyReport(url.searchParams.get('date') ?? undefined));
  }

  if (!(await authorized(req))) {
    return ok({ error: 'Unauthorized' }, { status: 401 });
  }

  return ok(listGeneratedReports());
});