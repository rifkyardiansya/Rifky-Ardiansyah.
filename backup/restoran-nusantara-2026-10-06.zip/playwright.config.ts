import { defineConfig, devices } from '@playwright/test';

const PORT = process.env.E2E_PORT ?? '3100';
const BASE_URL = `http://127.0.0.1:${PORT}`;

/**
 * Konfigurasi E2E (Playwright).
 *
 * Server produksi dijalankan otomatis oleh `webServer`, bukan `next dev`,
 * supaya hasil pengujian mendekati kondisi deployment sebenarnya.
 * Database memakai file terpisah (E2E_DB_FILE) agar data demo tidak tersentuh.
 */
export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: false,
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: process.env.CI
    ? [['github'], ['html', { open: 'never' }], ['list']]
    : [['list']],

  use: {
    baseURL: BASE_URL,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'off',
    actionTimeout: 15_000,
    locale: 'id-ID',
    timezoneId: 'Asia/Jakarta',
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    // Aktifkan bila browser sudah terpasang:
    // npx playwright install chromium
    // { name: 'mobile', use: { ...devices['Pixel 5'] } },
  ],

  webServer: {
    command: `npm run build && npx next start -p ${PORT}`,
    url: `${BASE_URL}/api/health`,
    reuseExistingServer: !process.env.CI,
    timeout: 300_000,
    stdout: 'pipe',
    stderr: 'pipe',
    env: {
      NODE_ENV: 'production',
      DATABASE_FILE: 'data/e2e-restoran.db',
      JWT_SECRET: 'e2e-secret-key-for-testing-only-minimum-32chars',
      PAYMENT_GATEWAY_SECRET: 'e2e-payment-secret',
      CRON_SECRET: 'e2e-cron-secret',
    },
  },
});