# Status Proyek — Restoran Nusantara

> Berkas ini adalah **catatan progres** proyek: apa yang sudah selesai, bagaimana
> cara menjalankan & mengujinya, bug apa saja yang sudah ditemukan, dan apa
> rencana selanjutnya.
>
> Terakhir diperbarui: **6 Oktober 2026** · Status: **Phase 5 selesai** ✅

---

## 1. Ringkasan

| Aspek | Keterangan |
|---|---|
| Nama | Restoran Nusantara — Sistem Informasi Restoran Terintegrasi |
| Tujuan | Prototype tugas Pemrograman Web semester 3 |
| Modul | 5 modul utama + payment gateway + notifikasi + panel admin |
| Stack | Next.js 14 (App Router) · TypeScript · Tailwind CSS · SQLite (better-sqlite3) |
| Auth | JWT HS256 + scrypt + RBAC 4 role |
| Realtime | Server-Sent Events (SSE) |
| Testing | 34 unit/integration test · 116 smoke test API check · 41 E2E test Playwright |
| Status build | ✅ `npm run build` sukses, 0 error TypeScript |
| Deployment | ✅ Dockerfile 3 tahap, docker-compose (app + PostgreSQL + Redis + MinIO), Nginx TLS, GitHub Actions CI/CD |
| PWA | ✅ Install prompt, keranjang IndexedDB, antrean offline, push notification, halaman offline |

---

## 2. Cara Menjalankan

```bash
npm install       # pasang dependency
npm run db:seed   # buat & isi database dengan data demo
npm run dev       # jalankan → http://localhost:3000
```

> Database juga ter-seed otomatis saat aplikasi diakses pertama kali.

### Akun Demo

| Username | Password | Role | Halaman yang boleh diakses |
|---|---|---|---|
| `admin` | `admin123` | Administrator | Semua + `/admin` |
| `manager` | `manager123` | Manager | Semua modul + `/reports`, `/notifications`, `/inventory` |
| `kasir` | `kasir123` | Kasir | `/pos`, `/kitchen`, `/booking`, `/reports` (cek UID) |
| `customer` | `customer123` | Customer | `/customer`, `/kitchen`, `/booking` |

Halaman `/`, `/customer`, `/kitchen`, `/booking`, `/login`, `/pay/[token]` **publik** (tanpa login).

### Perintah Penting

| Perintah | Fungsi |
|---|---|
| `npm run dev` | Server pengembangan |
| `npm run build` / `npm start` | Build & jalankan versi produksi |
| `npm run typecheck` | Cek tipe TypeScript (strict) |
| `npm run lint` | ESLint (`next/core-web-vitals`) |
| `npm test` | 34 unit/integration test (vitest) |
| `npm run smoke` | 47 smoke test API end-to-end (butuh dev server) |
| `npm run smoke:phase2` | 42 smoke test payment/notifikasi/PDF/SSE |
| `npm run smoke:phase5` | 27 smoke test laporan terjadwal & audit log |
| `npm run test:e2e` | 41 E2E test Playwright (build + `next start` otomatis, DB terpisah) |
| `npm run db:seed` | Isi data awal |
| `npm run db:status` | Ringkasan isi database + cek keseimbangan jurnal |
| `npm run db:reset` | Kosongkan & buat ulang database |

> ⚠️ `db:reset` **harus dijalankan saat dev server berhenti** (Windows mengunci file DB).
> Bila terkunci, skrip otomatis beralih ke mode truncate + seed ulang.

---

## 3. Yang Sudah Selesai

### Phase 1 — Foundation ✅
- [x] Project Next.js 14 + TypeScript strict + Tailwind CSS
- [x] **17 → 20 tabel database** (`src/server/db/schema.sql`)
- [x] Migration runner idempotent (ALTER TABLE guarded oleh PRAGMA)
- [x] Seed CLI + data demo realistis (8 menu, 10 meja, 8 bahan baku, 3 supplier)
- [x] **REST API 38 route** (37 endpoint di `/api/v1` + `/api/health`) sesuai blueprint §5 (`src/app/api/**`)
- [x] **Auth**: scrypt password hashing, JWT HS256 (jose), RBAC 4 role
- [x] **Middleware** proteksi halaman (`src/middleware.ts`)
- [x] Halaman login + panel admin
- [x] Validasi Zod di seluruh endpoint
- [x] Barcode scanner kamera (html5-qrcode / ZXing)

### Phase 3 — DevOps & Production Readiness ✅
- [x] **Security headers** — CSP, HSTS, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy
- [x] **Rate limiting** — sliding window: login 5× gagal/5 mnt, POS 30/mnt, webhook 120/mnt (counter direset setelah login berhasil)
- [x] **Health check** `/api/health` — DB, **keseimbangan jurnal**, subscriber SSE, memori, uptime
- [x] **Auto-migration + auto-seed saat koneksi pertama** — `schema.sql` (DDL idempotent) + `runMigrations()` (ALTER TABLE guarded PRAGMA) dijalankan di `createConnection()`, sehingga container baru siap menerima traffic tanpa `db:seed` manual (`src/server/db/client.ts:27`)
- [x] **Dockerfile 3 tahap** — non-root user, healthcheck, standalone output, volume data
- [x] **docker-compose** — app + PostgreSQL 16 + Redis 7 + MinIO; override produksi dengan resource limit
- [x] **Nginx** — TLS termination, gzip, cache statis, rate limit, SSE passthrough (buffering off)
- [x] **ESLint** — `next/core-web-vitals`, 0 warning/error
- [x] **GitHub Actions CI** — typecheck → lint → test → build → smoke test (Phase 1/2/5) → E2E Playwright → Docker build → Trivy scan
- [x] **GitHub Actions CD** — deploy VPS via SSH + health check + verifikasi

### Phase 4 — PWA & Offline ✅
- [x] **IndexedDB via Dexie** — keranjang tersimpan per meja, bertahan setelah browser ditutup
- [x] **Antrean pesanan offline** — pesanan saat offline diantre, dikirim otomatis saat koneksi kembali
- [x] **Install prompt** — event `beforeinstallprompt`, tombol "Pasang ke Home Screen"
- [x] **Push notification** — izin notifikasi + handler `push`/`notificationclick` di service worker
- [x] **Halaman `/offline`** — fallback saat seluruh jaringan & cache gagal
- [x] **Service worker** (v3) — network-first untuk halaman, cache-first untuk aset, stale-while-revalidate untuk gambar, API selalu network-only
- [x] **Ikon PWA 192 & 512 px** — di-generate tanpa dependency (`scripts/generate-icons.js`)
- [x] **Panel PWA** — indikator online/offline, jumlah antrean, status instalasi

### 5 Modul Utama ✅
1. **Customer Portal** (`/customer`) — scan barcode meja, katalog, keranjang, checkout, struk, tracking
2. **POS / Kasir** (`/pos`) — shift kasir, transaksi, void, Z-Report, struk 80mm + PDF
3. **Kitchen Display** (`/kitchen`) — 3 kolom status, timer, realtime via SSE
4. **Reservasi** (`/booking`) — ketersediaan slot, denah, 4 paket, deposit 25%, QR e-ticket, check-in, refund
5. **Stok & Bahan Baku** (`/inventory`) — alert menipis/kedaluwarsa, PO, GRN (moving average), stock opname, resep HPP
6. **Laporan Keuangan** (`/reports`) — P&L, Neraca, Arus Kas, penjualan, Buku Besar, PPN, ekspor CSV

### Phase 2 — Payment, Notifikasi, Realtime ✅
- [x] **Payment Gateway** — payment intent, redirect URL, halaman `/pay/[token]`
- [x] **Webhook terverifikasi** HMAC-SHA512 (timing-safe) + **idempotensi**
- [x] **QRIS payload EMVCo** dengan CRC16-CCITT
- [x] 5 channel: QRIS, Debit, Kredit, Virtual Account, Tunai
- [x] **Struk PDF 80mm** via pdf-lib (`/api/v1/pos/receipt/:id/pdf`)
- [x] **Notifikasi outbox** — 7 template (email/SMS/WhatsApp)
- [x] Halaman monitor `/notifications` (outbox + gateway + webhook log)
- [x] **Realtime SSE** (`/api/v1/events`) dengan heartbeat & auto-reconnect
- [x] Event bus in-process (`src/server/realtime/bus.ts`)

### Phase 5 — Laporan Terjadwal, Audit Log & E2E ✅
- [x] **Laporan penjualan harian terjadwal** (`src/server/services/schedule.service.ts`) — ringkasan omzet, transaksi, 5 menu terlaris, posisi keuangan (laba bersih, pajak terutang, nilai persediaan), data reservasi
- [x] **Endpoint cron** `/api/v1/cron/daily-report` — dilindungi shared secret (`CRON_SECRET`, timing-safe) atau sesi manager; **idempotent per tanggal** agar tidak mengirim notifikasi ganda
- [x] **Notifikasi `daily_report`** otomatis ke manager setelah laporan dibuat
- [x] **Audit log** `/api/v1/audit-logs` — LOGIN, CRON_DAILY_REPORT, dkk. + filter per aksi & statistik; hanya admin
- [x] **Panel laporan terjadwal** di `/reports` (`src/components/ScheduledReportPanel.tsx`)
- [x] **E2E test Playwright** 41 test lintas 5 modul (`tests/e2e/`) — server produksi dijalankan otomatis, DB terpisah (`data/e2e-restoran.db`)
- [x] **Health check** `/api/health` diperluas (jurnal, subscriber SSE, memori, uptime)

### Cakupan RBAC

| Halaman / Endpoint | customer | kasir | manager | admin |
|---|---|---|---|---|
| `/customer`, `/booking`, `/kitchen`, `/pay/[token]` | ✅ | ✅ | ✅ | ✅ |
| `/pos`, `/reports`, `/inventory`, `/booking` (cek UID) | ❌ | ✅ | ✅ | ✅ |
| `/notifications`, `/api/v1/notifications` | ❌ | ❌ | ✅ | ✅ |
| void transaksi, PO/GRN/stock opname | ❌ | ❌ | ✅ | ✅ |
| `/admin`, `/api/v1/audit-logs` | ❌ | ❌ | ❌ | ✅ |
| `/api/v1/cron/daily-report` | ❌ | ❌ | ✅ | ✅ |

> Outbox notifikasi memuat nama/email/telepon pelanggan, jadi dikunci `manager` ke atas
> (verified `scripts/smoke-phase2.ts`).

---

## 3b. Status Verifikasi (hasil run terakhir)

| Perintah | Hasil |
|---|---|
| `npm run typecheck` | ✅ 0 error |
| `npm run lint` | ✅ 0 warning / 0 error |
| `npm test` | ✅ 34 / 34 lulus |
| `npm run build` | ✅ sukses, semua route ter-render |
| `npm run smoke` | ✅ 47 / 47 |
| `npm run smoke:phase2` | ✅ 42 / 42 |
| `npm run smoke:phase5` | ✅ 27 / 27 |
| `npm run test:e2e` | ✅ 41 / 41 |

---

## 4. Daftar Bug yang Sudah Diperbaiki

Semua ditemukan oleh test suite / smoke test, dan sekarang punya **regression test**.

| # | Bug | Dampak | Perbaikan |
|---|---|---|---|
| 1 | `getDb()` membuat koneksi DB baru di setiap panggilan | **"database is locked"** — transaksi gagal | Koneksi di-cache pada `globalThis`, plus `busy_timeout` |
| 2 | Void transaksi: Dr saja tanpa Cr | Jurnal tidak seimbang | Dr Beban Operasional / Cr Kas |
| 3 | Stock opname: Dr saja saat stok berkurang | Jurnal tidak seimbang | Dr Beban / Cr Persediaan (atau sebaliknya) |
| 4 | Refund deposit: debit/kredit terbalik | **Liabilitas bertambah** saat pembatalan | Dr Liabilitas / Cr Kas / Cr Pendapatan penalti |
| 5 | Nilai stok seed ≠ jurnal pembuka | **Neraca tidak seimbang** | Jurnal pembuka dihitung dari nilai fisiknya (`sum(quantity × unit_cost)`) |
| 6 | Stok dipotong untuk order **belum dibayar** | Persediaan fisik ≠ buku | Stok dipotong hanya saat lunas, bersamaan dengan pencatatan HPP |
| 7 | **Webhook palsu memblokir pembayaran sah** | Denial of Service pada pembayaran | Idempotensi hanya berlaku untuk signature valid + sudah diproses |
| 8 | Baris jurnal bernilai 0 (menu tanpa resep) | `CHECK constraint failed` — order gagal total | Baris HPP/Persediaan dilewati bila nilainya nol |
| 9 | Audit log `audit_logs` jumlah parameter kurang | 500 saat ekspor laporan | Parameter `user_id` dilengkapi |
| 10 | PPN tidak konsisten (label 11% vs implementasi 10%) | Salah pada tampilan | Diseragamkan ke **PPN 10%** (jasa boga) di seluruh UI |
| 11 | Route API tidak sesuai blueprint (`/customer` vs `/customer/scan-barcode`) | Endpoint tidak ditemukan | Struktur route dirapikan mengikuti blueprint §5 |
| 12 | Route handler tanpa `force-dynamic` gagal saat prerender | Build/500 saat runtime | `export const dynamic = 'force-dynamic'` di 28 route |
| 13 | Smoke test Phase 5 tidak idempoten terhadap pengulangan | Gagal 2 check bila dijalankan ulang pada DB yang sama | Skrip memilih tanggal yang belum punya laporan + menguji ulang idempotensi |
| 14 | Smoke test Phase 1 menguras stok bahan habis | `penyesuaian stok -> 200` gagal setelah ~4× run (stok kopi habis) | Delta adaptif + pengembalian stok, jumlah stok akhir tidak berubah |

---

## 5. Catatan Teknis Penting (untuk presentasi)

### Kenapa SQLite, bukan PostgreSQL?
Blueprint menargetkan PostgreSQL + Redis + MinIO dalam monorepo. Untuk demo tugas,
SQLite (file lokal) dipilih agar **tidak perlu Docker**. Seluruh SQL yang dipakai
portabel — migrasi cukup mengganti driver + DDL.

### Kenapa PPN 10%?
Jasa boga/restoran dikenai **PPN 10%** (bukan 11% yang berlaku untuk barang luxury).
Implementasi konsisten di `src/lib/utils.ts` (`TAX_RATE = 0.1`), struk, dan seluruh laporan.

### Service Charge bukan pajak
Service charge 5% diperlakukan sebagai **pendapatan** (akun 4-100).
PPN dicatat sebagai **kewajiban** (akun 2-100). Keduanya bukan beban, sehingga
tidak mengurangi laba bersih — ini detail yang sering ditanyakan dosen.

### Neraca dijamin seimbang
Nilai persediaan di jurnal **selalu** berasal dari nilai fisiknya
(`sum(quantity × unit_cost)`), dan setiap transaksi menghasilkan pasangan
debit–kredit. Diverifikasi otomatis oleh:
- assertion `balanced` pada laporan `/reports`
- test `tests/domain.test.ts` & `tests/phase2.test.ts`
- `npm run db:status` yang mencetak status SEIMBANG / TIDAK SEIMBANG

### PPN 10% + service 5% dihitung berjenjang
`total = subtotal + (subtotal × 5%) + ((subtotal + service) × 10%)`
Implementasi: `calcTotals()` di `src/lib/utils.ts`.

---

## 6. Struktur Direktori

```
Prototype/
├── docs/
│   └── PROGRESS.md              ← berkas ini
├── public/
│   ├── manifest.json            ← PWA manifest
│   └── sw.js                    ← service worker (offline shell)
├── scripts/
│   ├── db.ts                    ← CLI database (seed/status/reset)
│   ├── smoke-api.ts             ← smoke test Phase 1
│   ├── smoke-phase2.ts          ← smoke test Phase 2
│   ├── smoke-phase5.ts          ← smoke test laporan terjadwal & audit log
│   ├── backup.js / verify-backup.js
│   └── generate-icons.js        ← ikon PWA tanpa dependency
├── src/
│   ├── app/                     ← halaman + REST API Route Handlers
│   │   ├── api/v1/              ← 37 endpoint + api/health
│   │   ├── customer|pos|kitchen|booking|inventory|reports|notifications|admin|login|pay|offline/
│   │   └── globals.css, layout.tsx, page.tsx
│   ├── components/              ← AppShell, UI kit, Receipt, FloorMap, BarcodeScanner, ScheduledReportPanel
│   ├── lib/                     ← store (state), api client, analytics, useRealtime, offlineCart, utils
│   ├── server/                  ← BACKEND (tidak masuk bundle browser)
│   │   ├── auth/                ← scrypt + JWT
│   │   ├── db/                  ← schema.sql, client (migrasi+seed), seed
│   │   ├── http/                ← ApiError, handler, requireUser, rate-limit
│   │   ├── realtime/            ← event bus
│   │   └── services/            ← order, booking, inventory, payment, notification, pdf, report, schedule
│   ├── types/                   ← TypeScript types
│   └── middleware.ts            ← proteksi halaman (satu-satunya; root-level Next.js)
├── tests/
│   ├── domain.test.ts           ← 17 test (Phase 1)
│   ├── phase2.test.ts           ← 17 test (Phase 2)
│   └── e2e/                     ← 41 test Playwright (auth, customer, POS, booking, stok, laporan)
├── data/restoran.db             ← database (di-gitignore, dibuat otomatis saat boot)
├── Dockerfile, docker-compose.yml, docker-compose.prod.yml, docker/nginx.conf
├── playwright.config.ts, vitest.config.ts, .eslintrc.json
├── package.json, next.config.mjs, tailwind.config.js, tsconfig.json
└── README.md                    ← dokumentasi lengkap
```

---

## 7. Rencana Selanjutnya

### Phase 6 — Penyempurnaan (opsional)
- [ ] Migrasi SQLite → PostgreSQL ( Prisma/TypeORM )
- [ ] Integrasi Midtrans/Xendit **sungguhan** (ganti `requestToGateway()`)
- [ ] Email/SMS provider sungguhan (ganti fungsi `dispatch()`)
- [ ] Socket.io untuk alur dua arah (ganti `bus.ts` + SSE)
- [ ] Worker background (BullMQ/antrian) agar laporan terjadwal tidak bergantung pada cron eksternal
- [ ] Redis untuk rate limiter & cache (antarmuka sudah disiapkan di `rate-limit.ts`)
- [ ] Migrasi gambar menu ke MinIO/S3
- [ ] Load test k6 + audit keamanan berkala

---

## 8. Catatan Backup

Karena **git belum terpasang** di komputer ini, backup dilakukan dengan cara:
1. Arsip ZIP seluruh source (tanpa `node_modules`, `.next`, `data`) → folder `backup/`
2. Database dapat dipulihkan dengan `npm run db:seed` (data demo)
3. `.gitignore` sudah disiapkan agar siap di-`git init` nanti

### Cara memakai git nanti (jika sudah terpasang)

```bash
git init
git add .
git commit -m "feat: 5 modul restoran + payment gateway + notifikasi (Phase 1-2)"
git remote add origin <url-repository>
git push -u origin main
```

---

*Catatan progres coursework semester 3 — Pemrograman Web*