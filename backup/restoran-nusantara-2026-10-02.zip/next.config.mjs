/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    // better-sqlite3 adalah modul native -> jangan di-bundle oleh webpack
    serverComponentsExternalPackages: ['better-sqlite3'],
  },
};

export default nextConfig;